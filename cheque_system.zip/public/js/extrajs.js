const firstAmountInput = document.getElementById("firstAmt");
const secondAmountInput = document.getElementById("secondAmt");
const thirdAmountInput = document.getElementById("thirdAmt");
const fourthAmountInput = document.getElementById("fourthAmt");
const fifthAmountInput = document.getElementById("fifthAmt");

const totalAmountDisplay = document.getElementById("totalAmountDisplay");

function calculateTotalAmount() {
  const firstAmount = parseFloat(firstAmountInput.value) || 0;
  const secondAmount = parseFloat(secondAmountInput.value) || 0;
  const thirdAmount = parseFloat(thirdAmountInput.value) || 0;
  const fourthAmount = parseFloat(fourthAmountInput.value) || 0;
  const fifthAmount = parseFloat(fifthAmountInput.value) || 0;

  const totalAmount = firstAmount + secondAmount + thirdAmount + fourthAmount + fifthAmount;

  totalAmountDisplay.textContent = totalAmount;
}

firstAmountInput.addEventListener("input", calculateTotalAmount);
secondAmountInput.addEventListener("input", calculateTotalAmount);
thirdAmountInput.addEventListener("input", calculateTotalAmount);
fourthAmountInput.addEventListener("input", calculateTotalAmount);
fifthAmountInput.addEventListener("input", calculateTotalAmount);








const hp = document.getElementById("hp");
const p7 = document.getElementById("p7");
const hpcc = document.getElementById("hpcc");
const result = document.getElementById("result");


// Add event listeners to the radio buttons
hp.addEventListener("change", updateInputValue);
p7.addEventListener("change", updateInputValue);
hpcc.addEventListener("change", updateInputValue);

function updateInputValue() {
  const hpac = "310313500004195";
  const p7ac = "3103135000007891";
  const hpcac = "3103298000000022";
  if (hp.checked) {
    result.value = hpac;
  } else if (p7.checked) {
    result.value = p7ac;
  } else if (hpcc.checked) {
    result.value = hpcac;
  }
}

function appearfor5s(event) {
  event.preventDefault(); 

  var message = document.querySelector(".updatemessage");
  message.style.display = "block"; 

  setTimeout(function () {
      message.style.display = "none"; 
  }, 5000); 
}



function printPage() {
  var body = document.getElementById('body').innerHTML;
  var data = document.getElementById("content-to-print").innerHTML;

  document.getElementById('body').innerHTML= data;
  data.style.transform = "rotate(90deg)";
  
  var tempElement = document.createElement("div");
  tempElement.innerHTML = data;
    


  document.getElementById('body').innerHTML = tempElement.innerHTML;
  window.print();
  contentToPrint.style.transform = "";
}
function printPageTwo() {
  var body = document.getElementById('body').innerHTML;
  var data = document.getElementById("content-to-print-2").innerHTML;

  document.getElementById('body').innerHTML= data;
  data.style.transform = "rotate(90deg)";
  
  var tempElement = document.createElement("div");
  tempElement.innerHTML = data;
    


  document.getElementById('body').innerHTML = tempElement.innerHTML;
  window.print();
  contentToPrint.style.transform = "";
}




function vdelete(button) {
  event.preventDefault();
  button.nextElementSibling.style.display = "block"; 


  setTimeout(function() {
    button.nextElementSibling.style.display = "none";
  }, 1500);
}



async function handleInput() {
  const searchTerm = document.getElementById('searchInput').value;

  if (!searchTerm.trim()) {
      document.getElementById('suggestions').innerHTML = '';
      return;
  }

  try {
      const response = await fetch(`/search-data?q=${encodeURIComponent(searchTerm)}`);
      const data = await response.json();

      const suggestionsDiv = document.getElementById('suggestions');
      suggestionsDiv.innerHTML = '';

      data.forEach(partyName => {
          const suggestionDiv = document.createElement('div');
          suggestionDiv.textContent = partyName;
          suggestionDiv.onclick = function () {
              document.getElementById('searchInput').value = partyName;
              suggestionsDiv.innerHTML = '';
          };
          suggestionsDiv.appendChild(suggestionDiv);
      });
  } catch (error) {
      console.error('Error fetching suggestions:', error);
  }
}

async function handleInput(inputId) {
  const input = document.getElementById(inputId);
  const searchTerm = input.value;

  if (!searchTerm.trim()) {
      clearSuggestions(inputId);
      return;
  }

  try {
      const response = await fetch(`/search-data?query=${encodeURIComponent(searchTerm)}`);
      const data = await response.json();

      const suggestionsDiv = document.getElementById(`suggestions_${inputId}`);
      suggestionsDiv.innerHTML = '';

      data.forEach(partyName => {
          const suggestionDiv = document.createElement('div');
          suggestionDiv.textContent = partyName;
          suggestionDiv.onclick = function () {
              input.value = partyName;
              clearSuggestions(inputId);
          };
          suggestionsDiv.appendChild(suggestionDiv);
      });
  } catch (error) {
      console.error('Error fetching suggestions:', error);
  }
}

function clearSuggestions(inputId) {
  const suggestionsDiv = document.getElementById(`suggestions_${inputId}`);
  suggestionsDiv.innerHTML = '';
}



















async function fetchSuggestions() {
  const response = await fetch('/api/suggestions');
  const suggestions = await response.json();
  return suggestions.map(suggestion => suggestion.name);
}

async function addSuggestion(newName) {
  const response = await fetch('/api/suggestions', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name: newName }),
  });
  const addedSuggestion = await response.json();
  return addedSuggestion.name;
}

const inputBox = document.getElementById('inputBox');
const suggestionsContainer = document.getElementById('suggestions');
const addButton = document.getElementById('addButton');

async function showSuggestions() {
  const inputText = inputBox.value.toLowerCase();
  const suggestions = await fetchSuggestions();

  const filteredSuggestions = suggestions.filter(suggestion =>
      suggestion.toLowerCase().includes(inputText)
  );

  // Display suggestions
  displaySuggestions(filteredSuggestions);

  // Show/hide add button based on input
  addButton.style.display = filteredSuggestions.length === 0 && inputText.trim() !== '' ? 'block' : 'none';
}

function displaySuggestions(suggestions) {
  // Clear previous suggestions
  suggestionsContainer.innerHTML = '';

  // Display the suggestions
  suggestions.forEach(suggestion => {
      const suggestionItem = document.createElement('div');
      suggestionItem.className = 'suggestion-item';
      suggestionItem.textContent = suggestion;
      suggestionItem.onclick = () => selectSuggestion(suggestion);
      suggestionsContainer.appendChild(suggestionItem);
  });

  // Show the suggestions container
  suggestionsContainer.style.display = suggestions.length > 0 ? 'block' : 'none';
}

async function selectSuggestion(suggestion) {
  // Set the selected suggestion in the input box
  inputBox.value = suggestion;
  // Hide suggestions
  suggestionsContainer.style.display = 'none';
  // Hide the add button
  addButton.style.display = 'none';
}

async function addName() {
  const newName = inputBox.value.trim();
  if (newName !== '') {
      // Add the name to the database
      const addedName = await addSuggestion(newName);
      // Clear the input box
      inputBox.value = '';
      // Hide the add button
      addButton.style.display = 'none';

      // Update suggestions and display them
      const updatedSuggestions = await fetchSuggestions();
      displaySuggestions(updatedSuggestions);
  }
}

// Initial fetch and display of suggestions
showSuggestions();



// function downloadTable() {
//   const table = document.getElementById("table1");
//   const rows = table.querySelectorAll("tr");
//   const csvContent = Array.from(rows, (row) => {
//     const columns = row.querySelectorAll("td, th");
//     return Array.from(columns, (column) => `"${column.innerText}"`).join(",");
//   }).join("\n");
//   const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
//   const a = document.createElement('a');
//   a.href = URL.createObjectURL(blob);
//   a.download = 'table_data.csv';
//   document.body.appendChild(a);
//   a.click();
//   document.body.removeChild(a);
// }
function downloadTable() {
  const table = document.getElementById("table1");
  const rows = table.querySelectorAll("tr");
  const csvContent = Array.from(rows, (row) => {
    const columns = row.querySelectorAll("td, th");
    return Array.from(columns, (column, index) => {
      // Add a single quote only to the values in the second column
      return index === 1 ? `'${column.innerText}` : column.innerText;
    }).join(",");
  }).join("\n");

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'table_data.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
